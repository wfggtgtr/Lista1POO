﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex01
{
    internal class Retangulo
    {
        private int bas;
        private int alt;
        private int area;

        public void setBase(int n)
        {
            bas = n;
        }
        public void setAltura(int n)
        {
            alt = n;
        }
        public int getBase()
        {
            return bas;
        }
        public int getAltura()
        {
            return alt;
        }
        public int getArea()
        {
            return area;
        }
        public void calcularAerea()
        {
            area = bas * alt;
        }
    }
}
