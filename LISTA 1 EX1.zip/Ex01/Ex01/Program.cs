﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Retangulo ret;
            ret = new Retangulo();

            Console.WriteLine("Digite o valor da base: ");
            ret.setBase(int.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o valor da Altura: ");
            ret.setAltura(int.Parse(Console.ReadLine()));

            ret.calcularAerea();

            Console.WriteLine("A area do retangulo com Base {0} e Altura {1} é {2}",ret.getBase(), ret.getAltura(), ret.getArea());
        }
    }
}
