﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTA1_EX3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Quadrado area1;
            area1 = new Quadrado();


            Console.WriteLine("Insira o valor da diagonal do quadrado(n): ");
            area1.setDiag(int.Parse(Console.ReadLine()));

            area1.calcular();

            Console.WriteLine("");

            Console.WriteLine("A área do quadrado de diagonal  {0}m é {1}m²");
            area1.getDiag();  
            area1.getArea();
        }
    }
}
