﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTA_1_EX8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Maior Valores1;
            Valores1 = new Maior();

            Console.WriteLine("Insira o 1° Valor:  ");
            Valores1.setV1(int.Parse(Console.ReadLine()));

            Console.WriteLine("Insir o 2° Valor:   ");
            Valores1.setV2(int.Parse(Console.ReadLine()));

            Valores1.calcular();

            Console.WriteLine("");

            Console.WriteLine("O maior valor é {0}");
            Valores1.getMaior();
        }
    }
}
