﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTA_1_EX6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Quilômetros conversao1;
            conversao1 = new Quilômetros();

            Console.WriteLine(" Insira um valor (Em milhas marítimas):   ");
            conversao1.setMilhaM(int.Parse(Console.ReadLine()));

            conversao1.calcular();

            Console.WriteLine("");

            Console.WriteLine("{0} Milhas Marítims Equivalem à {1} Quilômetros");
            conversao1.getMilhaM();
            conversao1.getKm();

        }
    }
}
