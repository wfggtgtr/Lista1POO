﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2
{
    internal class Quadrado
    {
        private int A;
        private int area;

        public void setAresta(int n)
        {
            A = n;
        }
        public int getAresta()
        {
            return A;
        }
        public int getArea()
        {
            return area;
        }

    public void calcularArea()
        {
            area = A * A;
        }

    }
}
