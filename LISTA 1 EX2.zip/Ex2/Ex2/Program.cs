﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Quadrado quad;
            quad = new Quadrado();

            Console.WriteLine("Digite o valor da aresta: ");
            quad.setAresta(int.Parse(Console.ReadLine()));

            quad.calcularArea();

            Console.WriteLine("A area do quadrado é {0}", quad.getArea());
        }
    }
}
